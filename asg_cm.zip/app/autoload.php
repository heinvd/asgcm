<?php

require("classes/Database.php");
require("classes/Contacts.php");
